﻿namespace _07.Timer
{
	using System;
	using System.Threading;

	class Timer
	{
		public static void Print()
		{
			Console.WriteLine("Function called!");
		}
	}
}
